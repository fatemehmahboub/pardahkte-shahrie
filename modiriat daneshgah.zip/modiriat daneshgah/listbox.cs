﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form12
{
    public partial class listbox : Form
    {
        public listbox()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
          listBox1.Items.Add("پرداخت با موفقیت انجام شد" );
            listBox1.Items.Add(":شناسه پرداخت");
            listBox1.Items.Add(":تاریخ وساعت پرداخت");
            
        }
    }
}
