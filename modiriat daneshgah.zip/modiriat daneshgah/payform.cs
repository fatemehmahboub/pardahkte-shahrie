﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form12
{
    public partial class payform : Form
    {
        public payform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "فاطمه" && textBox2.Text == "محبوب" && textBox3.Text == "140112039030")
            {
                searchform sh = new searchform();   
                sh.Show();

            }
            else
            {
                MessageBox.Show("erorr");
            }
        }

        private void payform_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            
        }
    }
}
